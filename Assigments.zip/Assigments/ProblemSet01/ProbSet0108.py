# Implement a function that satisfies the specification. Use a try-except block.
"""Assumes: vect1 and vect2 are lists of equal length of numbers
	Returns: a list containing the meaningful values of
	vect1[i]/vect2[i]"""


def getRatios(vect1, vect2):
    outlist = []
    temp = 0
    try:
        for i in range(0, len(vect1)):
            temp = int(vect1[i]) / int(vect2[i])
            outlist.append(temp)
        return outlist
    except:
        print("Divided by zero...!")
        exit(0)


in1 = input("Enter numbers:")
inf1 = in1.split(" ")
in2 = input("Enter numbers:")
inf2 = in2.split(" ")
print(getRatios(inf1, inf2))
