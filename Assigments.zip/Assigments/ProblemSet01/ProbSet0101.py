# Write a program that examines three variables—x, y, and z— and
# prints the largest odd number among them. If none of them are odd, it should print a message to that effect.
print("Enter three numbers:")
nums = [int(i) for i in input().split()[:3]]
count = 0
arr = []
for num in nums:
    if num % 2 != 0:
        arr.append(num)
        count = count + 1
max = 0
if count > 0:
    for i in range(0, len(arr)):
        if arr[i] > max:
            max = arr[i]
    print("Max odd number:", max)
else:
    print("No odd number found!!!")
