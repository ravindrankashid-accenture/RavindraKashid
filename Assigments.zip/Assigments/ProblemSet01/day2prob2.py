# Write a python script to validate the strong password (combination of characters alphabets and numbers,special
# characters in it. if not weak password) eg: Acc9876$ it is strong password abcd it is weak password
import re

Password = input("Enter password \n")

specials = re.compile('[@_!#$%^&*()<>?/\|}{~:]')

if re.search("[A-Z]", Password) and re.search(specials, Password) and re.search("[a-z]", Password) and \
        re.search("[0-9]", Password):
    print("Strong Password")
else:
    print("Weak Password")
