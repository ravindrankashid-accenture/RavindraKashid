# Write a program that asks the user to input 10 integers, and then prints the largest odd number that was entered.
# If no odd number was entered, it should print a message to that effect.
print("Enter ten numbers:")
nums = [int(i) for i in input().split()[:10]]
count = 0
arr = []
for num in nums:
    if num % 2 != 0:
        arr.append(num)
        count = count + 1
max = 0
if count > 0:
    for i in range(0, len(arr)):
        if arr[i] > max:
            max = arr[i]
    print("Max odd number:", max)
else:
    print("No odd number found!!!")
