# A palindrome is a word that is spelled the same backward and forward, like "Malayalam" and "Noon" .
# Recursively, a word is a palindrome if the first and last letters are the same and the middle is a palindrome.
# Write a function called is_palindrome that takes a string argument and returns True if it is a palindrome
# and False otherwise. Remember that you can use the built-in function len to check the length of a string.
# Use the function definition

def is_plaindrome(string):
    str2 = string[::-1]
    if string == str2:
        print("Given string is palindrome.")
    else:
        print("Given string is not a palindrome.")


a = input("Enter a string:")
is_plaindrome(a)
