# Declare a List containing Numbers a) Get only Even Numbers b) Perform sum of those even Numbers
mylist = [2, 3, 5, 8, 12, 9]
# mylist = input("Enter numbers\n")
sumofeve = []
total = 0
i = 0
print("Given list", mylist)
for num in mylist:
    if num % 2 == 0:
        sumofeve.append(num)
print("a) Even numbers from given list:")
for num in sumofeve:
    print(num, end=" ")

for num in sumofeve:
    total = total + num

print("\nb) Sum of even numbers from list is:", total)
