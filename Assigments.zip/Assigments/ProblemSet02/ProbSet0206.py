# Implement a function that satisfies the specification. Use a try-except block.
def findAnEven(numlist):
    Flag = 0
    try:
        for i in numlist:
            if int(i) % 2 == 0:
                Flag = 1
                return i
        if Flag == 0:
            raise ValueError
    except ValueError:
        print("Error: No single even number found in given list..!")


a = input("Enter a list of number: ")
b=a.split(" ")
print(b)
print("Even no is: ", findAnEven(b))
