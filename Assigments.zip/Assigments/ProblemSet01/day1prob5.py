year = int(input("Enter a year:"))

if year % 4 == 0 and year % 400 == 0 and not year % 100 == 0:
    print(year, " is a Leap year!")
else:
    print(year, " is not a leap year!")
