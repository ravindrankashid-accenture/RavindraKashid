# Write the below contents to a file named 'marks.txt' using python script
# Science = 50 Maths = 90 English = 85 Tamil = 92
# a) Read the file and calculate the total sum of marks available there
import re
file = open("C:\Python\datain.txt", "w")

file.write("Science = 50 Maths = 90 English = 85 Tamil = 92")
file.close()

file = open("C:\Python\datain.txt")
sum1=0
for cont in file:
    spl = cont.split(" ")
    for num in spl:
        if num.isnumeric():
            sum1 = sum1+int(num)
    print(sum1)

file.close()

