students = {'student1': [68, 98, 88], 'student2': [69, 58, 77]}
# Total and average marks of each student
sum = 0;
avg = 0;
count = 0;
for stud in students:
    sum = 0
    avg = 0
    count = 0
    for mark in students[stud]:
        sum = sum + mark
        print(mark, end=" ")
        count = count + 1
    print("Total marks:", sum)
    avg = sum / count
    print("Average of student:%.2f" % avg)
