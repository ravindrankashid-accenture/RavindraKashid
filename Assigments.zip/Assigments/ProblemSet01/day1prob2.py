# Get ur full name, age as input from user and print first name and last name , age using string slicing a) 2 raw_input
# get name and age b) print first name and last name and age c) WHEN age >= 18 , he/she is eligible to vote d)
# WHEN age < 18 ,he/she is not eligible to vote
from pip._vendor.distlib.compat import raw_input

print("Enter your fullname and age:")
name = raw_input()
name1 = name.split(" ")
print(name1[0], name1[2], name1[3])

if int(name1[3]) >= 18:
    print("Your eligible to vote!")
else:
    print("Your not eligible to vote!!!")
