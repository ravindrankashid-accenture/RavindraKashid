import csv


class Summary_Genrator:
    def store(self, finaldata):
        with open('C:\pyfiles\sapient_test_requirement\output.csv', mode='w', newline="") as trans_file:
            csvwriter = csv.writer(trans_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            csvwriter.writerow(['Client_Id', 'Transaction_Type', 'Transaction_Date', 'Priority_Flag',
                                'Processing_fee'])
            for i in range(len(finaldata)):
                csvwriter.writerow([finaldata[i][0], finaldata[i][1], finaldata[i][2],
                                    finaldata[i][3], finaldata[i][4]])
        trans_file.close()
