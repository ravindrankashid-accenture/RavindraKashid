# Observe the following function definitions. They Calculate the Factorial as per the Mathematical definition
# 1! = 1 (n + 1)! = (n + 1) * n! Implement factI(n) as an Iterative Implementation & factR(n) as a Recursive Implementation

def factI(n):
    temp = 1
    for i in range(1, n + 1):
        temp = temp * i
    return temp


def factR(n):
    if n >= 1:
        return n * factR(n - 1)
    else:
        return 1


a = int(input("Enter a number: "))
result1 = factI(a)
result2 = factR(a)
print("Factorial of {0} is {1} by factI and {2} by factR ".format(a, result1, result2))
