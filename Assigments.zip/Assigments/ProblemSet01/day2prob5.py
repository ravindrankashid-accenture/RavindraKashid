# Suppose the following input is supplied to the program: 34,67,55,33,12,98
# Then, the output should be: ['34', '67', '55', '33', '12', '98'] ('34', '67', '55', '33', '12', '98')
inarr = input("Enter numbers:")
mylist = []
for num in inarr:
    mylist.append(num)

mytuple = tuple(mylist)

mylist1 = [mylist, mytuple]
print(mylist1)
