# Write a program that accepts a sentence and calculate the number of upper case letters
# and lower case letters. Suppose the following input is supplied to the program:
# Hello world! Then, the output should be: UPPER CASE 1 LOWER CASE 9
instr = input("Enter a sentence\n")
lower = 0
upper = 0
for ch in instr:
    if ch.isupper():
        upper = upper + 1
    else:
        lower = lower + 1

print('UPPER CASE {0} LOWER CASE {1}'.format(upper, str(lower)))
