# Write a Python program to perform sum of three given integers. However, if any of
# the two values are equal then sum will be zero (eg : 2+1+1 = 0)
print("Enter three numbers:")
nums = [int(i) for i in input().split()[:3]]
flag = 1
suma = 0
j = 0
i = 0
count = 0
for i in range(0, len(nums)):
    for j in range(0, len(nums)):
        if i != j:
            if nums[i] == nums[j]:
                suma = 0
                flag=0
                break
            else:
                if count <= 2 and flag == 1:
                    suma = suma + nums[j]
                    count = count + 1
                else:
                    break
print(suma)
