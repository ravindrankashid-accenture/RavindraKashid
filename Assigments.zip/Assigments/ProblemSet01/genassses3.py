def tab(num):
    for i in range(1, 11):
        yield num * i


for i in tab(14):
    print(i)
