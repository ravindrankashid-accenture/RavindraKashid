# Write 2 decorator function to spilt the given string and to join them using different delimiter
# (eg. instead of space give $).

def func1(f):
    def fun2():
        string=f()
        print(string)
        nstr="$".join(string)
        print(nstr)
    return fun2




# @ func1(string)
def strf(string):
    return string.split(" ")

s="This is a demo string"
funn=func1(strf(s))
print(funn())