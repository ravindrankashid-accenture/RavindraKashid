# Calculating your birth number in numerology 26/11/1978 2+6+1+1+1+7+8 = 8
datea = input("Enter your date of birth:")
dat = datea.split("/")


def selfadder(number):
    temp = 0
    suma = 0
    while number > 0:
        temp = number % 10
        suma = suma + temp
        number = int(number / 10)
    return suma


megaout = 0
mystr = ""
for nos in dat:
    mystr = mystr + nos
megaout = int(mystr)
print(mystr)
out = selfadder(int(megaout))
if out > 9:
    megaout = selfadder(out)
    print("Your birth number in numerology is: ", megaout)
else:
    print("Your birth number in numerology is: ", out)
