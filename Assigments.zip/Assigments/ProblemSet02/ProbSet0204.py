# Write a program that computes the decimal equivalent of the binary number 10011?
a = int(input("Enter a number: "))
print(bin(a).replace("0b",""))
