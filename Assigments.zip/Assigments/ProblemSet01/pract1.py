
in1= input()
in2 = input()
print(neww)
if in1.__eq__(in2):
    print("Equal")
else:
    print("not equal")