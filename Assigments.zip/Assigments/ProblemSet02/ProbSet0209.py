# Write a function NewtonSqrt() to abstract the Newton's Method of calculation Square roots.
import math


def NewtonSqrt(num):
    x = 1
    y=0

    y = (x + num / x) / 2
    return y


a = int(input("Enter a num: "))
result1 = math.sqrt(a)
result2 = NewtonSqrt(NewtonSqrt(a))

print(result1, result2)
