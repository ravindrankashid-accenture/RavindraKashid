# Implement a function that meets the specification below. Use a try-except block.
import re


def sumDigits(s):
    suma = 0
    try:
        if bool(re.search(r'\d', s)):
            for i in range(len(s)):
                if s[i].isdigit():
                    suma = suma + int(s[i])
            return suma
        else:
            raise ValueError
    except ValueError:
        print("String with no digits Error!!!")


a = input("Enter a string: ")
print(sumDigits(a))
