inventory = {
    'gold': 500,
    'pouch': ['flint', 'twine', 'gemstone'],
    'backpack': ['xylophone', 'dagger', 'bedroll', 'bread loaf']
}
print(inventory)
# a) Add a key to inventory called 'pocket'.
print("Adding a key to inventory called 'pocket'.")
inventory.update(pocket="")
print(inventory)

# b) Set the value of 'pocket' to be a list consisting of the strings 'seashell', 'strange berry', and 'lint'.
print("Set list 'seashell', 'strange berry', and 'lint' to pocket.")
mylist = ['seashell', 'strange berry', 'lint']
inventory.update(pocket=mylist)
print(inventory)

# .sort()the items in the list stored under the 'backpack' key.

print("Before sorting 'backpack' list:")
print(inventory['backpack'])
inventory['backpack'].sort()
print("After sorting 'backpack' list:")
print(inventory['backpack'])

# d) Then .remove('dagger') from the list of items stored under the 'backpack' key.
inventory['backpack'].remove("dagger")
print(inventory['backpack'])

# e) Add 50 to the number stored under the 'gold' key.
print(inventory['gold'])
inventory['gold']=50
print(inventory['gold'])