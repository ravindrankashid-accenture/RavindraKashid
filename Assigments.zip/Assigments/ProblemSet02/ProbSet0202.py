# A number, a, is a power of b if it is divisible by b and a/b is a power of b.
# Write a function called is_power that takes parameters a and b
# and returns True if a is a power of b. Note: you will have to think about the base case.

def is_power(num1, num2):
    if num1 % num2 == 0:
        temp = num1 / num2
        if temp % num2 == 0:
            return True
        else:
            return False
    else:
        return False


print("Enter two numbers:")
a = int(input())
b = int(input())
Flag = is_power(a, b)
if Flag:
    print("{0} is power of {1}".format(a, b))
else:
    print("{0} is not power of {1}".format(a, b))
