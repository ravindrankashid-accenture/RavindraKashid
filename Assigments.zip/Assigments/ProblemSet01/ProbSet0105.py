# Write a program that asks the user to enter an integer and prints two integers, root and pwr, such that 0 < pwr < 6
# and root**pwr is equal to the integer entered by the user. If no such pair of integers exists, it should
# print a message to that effect.

num = int(input("Enter a number: "))
# if 0>=  <= 6:
root = num ** .5
num1 = 0
count = 1
while num != num1:
    num1 = root * root
    count = count + 1
    if num1 > num:
        break
num2 = root ** count
if num == num2:
    print("Root is: {0} and Power is: {1}".format(root, count))
else:
    print("Given no is not a perfect square...!")