# Write a function isIn() that accepts two strings as arguments and
# returns True if either string occurs anywhere in the other, and False otherwise.
# Hint: you might want to use the built-in str operation in.
def isIn(str1, str2):
    if str1.find(str2) != -1:
        return True
    elif str2.find(str1) != -1:
        return True
    else:
        return False


stg1 = input("Enter string 1: ")
str2 = input("Enter string 2: ")
print(isIn(stg1, str2))
