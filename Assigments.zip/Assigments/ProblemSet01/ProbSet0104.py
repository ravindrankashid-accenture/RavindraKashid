# The volume of a sphere with radius r is 4/3pr3. What is the volume of a sphere with radius 5?
# Hint: 392.7 is wrong!
radius = int(input("Enter the radius of sphere: "))
ans = (4 / 3) * 3.14 * (radius ** 3)
print("Volume of sphere is: %.2f" % ans)

# Suppose the cover price of a book is Rs.24.95, but bookstores get a 40% discount. Shipping costs
# Rs.3 for the first copy and 0.75p for each additional copy. What is the total wholesale cost for
# 60 copies?
total = 24.95
total = 24.95 - (total * .4)
total = total + 3
total = total + (.75 * 59)
print("Total wholesale cost for 60 copies is: ", total)

# If I leave my house at 6:52 am and run 1 mile at an easy pace (8:15 per mile), then 3 miles at
# tempo (7:12 per mile) and 1 mile at easy pace again, what time do I get home for breakfast?
time = "6:52".split(":")
hr= time[0]
min= time[1]
sec = 00
print("Enter no of miles:")
miles = [int(i) for i in input().split()[:3]]
pace = input("Choose pace:\n 1: Easy \n 2: Tempo")
paces = pace.split(" ")
for i in range(0, len(miles)):
    if paces[i].lower() == "easy":
        sec = 15 * miles[i]
        min = min + 15
        if min >59:
            hr= hr+

