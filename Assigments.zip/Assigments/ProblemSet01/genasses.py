# 1.Generate  the date of all Saturdays in a given year using generators.
import calendar
from datetime import timedelta, date
import datetime


def satdays(year):
    date1 = date(year, 1, 1)
    date1 = date1 + timedelta(days=5 - date1.weekday())
    # print(calendar.day_name[d.weekday()])
    while date1.year == year:
        yield date1
        date1 += timedelta(days=7)


for sdate in satdays(2020):
    print(sdate)
