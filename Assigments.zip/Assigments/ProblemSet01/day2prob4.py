# Write a program which accepts a sequence of comma-separated numbers from console and generate
# a list and a tuple which contains every number.

inarr = input("Enter comma-separated numbers:")
inarr1 = inarr.split(',')
mylist = []
mytuple = ()

for num in inarr1:
    mylist.append(num)

print("Created list from input:", mylist)
mytuple = tuple(mylist)

print("Created tuple from input:", mytuple)
