# Read a file and generate the words which starts with vowels using generators and write the result in another file.

def vowstart(line):
    words = line.split(" ")
    for i in range(len(words)):
        if words[i].startswith("a") or words[i].startswith("e") or words[i].startswith("i") or words[i].startswith(
                "o") or words[i].startswith("u"):
            yield words[i]


file = open("C:\myFiles\input.txt", "r")
data = file.read()
print(data)
file1 = open("C:\myFiles\output.txt", "w")
for words in vowstart(data):
    words = words + " "
    file1.write(words)
file.close()
file1.close()
