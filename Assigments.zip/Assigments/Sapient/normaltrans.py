class normal:
    Client_Id, Security_Id, Transaction_Date = "", "", ""
    Transaction_Type, External_Transaction_Id, Priority_Flag = "", "", ""

    def __init__(self, External_Transaction_Id, Client_Id, Security_Id, Transaction_Date, Transaction_Type,
                 Priority_Flag):
        self.External_Transaction_Id = External_Transaction_Id
        self.Client_Id = Client_Id
        self.Security_Id = Security_Id
        self.Transaction_Date = Transaction_Date
        self.Transaction_Type = Transaction_Type
        self.Priority_Flag = Priority_Flag

    def process(self):
        Processing_fee = "proccesing fee"
        s = self.Priority_Flag
        if 'Y' in s:
            Processing_fee = "500"
        elif 'N' in s and (self.Transaction_Type == "SELL" or self.Transaction_Type == "WITHDRAW"):
            Processing_fee = "100"
        elif 'N' in s and (self.Transaction_Type == "BUY" or self.Transaction_Type == "DEPOSIT"):
            Processing_fee = "50"
        temp = [self.Client_Id, self.Transaction_Type, self.Transaction_Date, self.Priority_Flag, Processing_fee]
        return temp
