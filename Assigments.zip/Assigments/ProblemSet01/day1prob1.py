# Get first name and last name from user and print your full name
firstn = input("Enter your first name:")
lastn = input("Enter your last name:")
print("Your full name: {0} {1}".format(firstn,lastn))