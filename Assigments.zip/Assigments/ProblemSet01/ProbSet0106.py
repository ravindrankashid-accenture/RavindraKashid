# Let s be a string that contains a sequence of decimal numbers separated by commas, e.g., s = '1.23,2.4,3.123'.
# Write a program that prints the sum of the numbers in s.

s = input("Enter sequence:")
nums = s.split(",")
suma = 0.00
for i in range(0, len(nums)):
    suma = suma + float(nums[i])

print(suma)