import intradaytrans
import normaltrans
from summryrepo import Summary_Genrator

Input_file = open("C:\pyfiles\sapient_test_requirement\Input data.csv", "r")
var = Input_file.readlines()
Client_Id = []
Security_Id = []
Transaction_Date = []
Transaction_Type = []
External_Transaction_Id = []
Priority_Flag = []
for i in range(1, len(var)):
    temp = var[i].split(",")
    External_Transaction_Id.append(temp[0])
    Client_Id.append(temp[1])
    Security_Id.append(temp[2])
    Transaction_Type.append(temp[3])
    Transaction_Date.append(temp[4])
    Priority_Flag.append(temp[6][0])
data = []
store = []
for i in range(0, len(Transaction_Date)):
    for j in range(0, len(Transaction_Date)):
        if i != j:
            if Transaction_Date[i] == Transaction_Date[j] and (
                    (Transaction_Type[i] == "BUY" and Transaction_Type[i] == "SELL") or
                    (Transaction_Type[i] == "SELL" and Transaction_Type[i] == "BUY")):
                obj = intradaytrans.intra(External_Transaction_Id[i], Client_Id[i], Security_Id[i], Transaction_Date[i],
                                          Transaction_Type[i],
                                          Priority_Flag[i])
                obj1 = intradaytrans.intra(External_Transaction_Id[j], Client_Id[j], Security_Id[j],
                                           Transaction_Date[j],
                                           Transaction_Type[j],
                                           Priority_Flag[j])
                data.append(obj.process())
                data.append(obj1.process())
                store.append(i)
                store.append(j)
    if i not in store:
        obj1 = normaltrans.normal(External_Transaction_Id[i], Client_Id[i], Security_Id[i], Transaction_Date[i],
                                  Transaction_Type[i], Priority_Flag[i])
        data.append(obj1.process())

nw = sorted(data, key=lambda cli: (cli[0], cli[1], cli[2].split("/"), cli[3]))
sumobj = Summary_Genrator()
sumobj.store(nw)
Input_file.close()
