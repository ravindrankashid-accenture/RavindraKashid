# From your DOB till date generate all leap years using generators.
from datetime import date


def leap(bdate):
    bdatey = bdate.year
    # print(bdatey)
    while bdatey != 2020:
        if (bdatey % 4) == 0:
            if (bdatey % 100) == 0:
                if (bdatey % 400) == 0:
                    yield bdatey
            else:
                yield bdatey
        bdatey = bdatey + 1


bdat = date(1994, 4, 17)
for i in leap(bdat):
    print(i)

